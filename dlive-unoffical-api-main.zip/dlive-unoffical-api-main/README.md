# dlive-unoffical-api
<p>DLive yayın platformu için, istenilen kişinin yayında olup olmadığını kontrol eden basit bir API sistemi.<br><br>
  <hr>
API, NodeJS ile oluşturulmuştur.NodeJS üzerinde bu sistem aktif edildiği zaman DLive üzerinden yayıncı sorgulaması yapıp, yayında olup olmadığını öğrenebilir.Çeşitli platformlarda kullanabilirsiniz.<br>
<hr>
Kaynak kodlar için "index.js" kısmını inceleyiniz.
<p>
